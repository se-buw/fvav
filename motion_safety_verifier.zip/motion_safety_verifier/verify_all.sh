#!/bin/bash

cd /home/seav/seav3/src/motion_safety_verifier

echo "Running Dafny verification..."

dafny /compile:0 motion_safety_verifier.dfy
dafny /compile:0 ControllerVerification.dfy
dafny /compile:0 RobotMotionSafetyVerification.dfy

echo "Verification complete."
