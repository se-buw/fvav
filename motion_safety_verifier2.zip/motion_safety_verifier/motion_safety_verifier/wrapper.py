import subprocess
import rclpy
from rclpy.node import Node


class MotionSafetyVerifier(Node):
    def __init__(self):
        super().__init__('motion_safety_verifier')

        self.get_logger().info('Dafny Motion Safety Verification started')

        script_path = '/home/seav/seav3/src/motion_safety_verifier/verify_all.sh'

        result = subprocess.run(
            ['bash', script_path],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            self.get_logger().info('Dafny verification successful')
            self.get_logger().info('Verified property 1: joystick has highest priority in twist_mux')
            self.get_logger().info('Verified property 2: Ackermann controller uses /cmd_vel_safe')
            self.get_logger().info('Verified property 3: complete motion safety pipeline is valid')
            self.get_logger().info(result.stdout)
        else:
            self.get_logger().error('Dafny verification failed')
            self.get_logger().error(result.stderr)


def main(args=None):
    rclpy.init(args=args)
    node = MotionSafetyVerifier()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
