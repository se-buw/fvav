import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def Priority(s):
        source0_ = s
        if True:
            if source0_.is_Joystick:
                return 100
        if True:
            if source0_.is_Tracker:
                return 20
        if True:
            if source0_.is_Direction:
                return 15
        if True:
            if source0_.is_Navigation:
                return 10
        if True:
            return 5

    @staticmethod
    def VerifyPriority():
        pass
        pass


class MotionSource:
    @_dafny.classproperty
    def AllSingletonConstructors(cls):
        return [MotionSource_Joystick(), MotionSource_Tracker(), MotionSource_Direction(), MotionSource_Navigation(), MotionSource_Nav2()]
    @classmethod
    def default(cls, ):
        return lambda: MotionSource_Joystick()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_Joystick(self) -> bool:
        return isinstance(self, MotionSource_Joystick)
    @property
    def is_Tracker(self) -> bool:
        return isinstance(self, MotionSource_Tracker)
    @property
    def is_Direction(self) -> bool:
        return isinstance(self, MotionSource_Direction)
    @property
    def is_Navigation(self) -> bool:
        return isinstance(self, MotionSource_Navigation)
    @property
    def is_Nav2(self) -> bool:
        return isinstance(self, MotionSource_Nav2)

class MotionSource_Joystick(MotionSource, NamedTuple('Joystick', [])):
    def __dafnystr__(self) -> str:
        return f'MotionSource.Joystick'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, MotionSource_Joystick)
    def __hash__(self) -> int:
        return super().__hash__()

class MotionSource_Tracker(MotionSource, NamedTuple('Tracker', [])):
    def __dafnystr__(self) -> str:
        return f'MotionSource.Tracker'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, MotionSource_Tracker)
    def __hash__(self) -> int:
        return super().__hash__()

class MotionSource_Direction(MotionSource, NamedTuple('Direction', [])):
    def __dafnystr__(self) -> str:
        return f'MotionSource.Direction'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, MotionSource_Direction)
    def __hash__(self) -> int:
        return super().__hash__()

class MotionSource_Navigation(MotionSource, NamedTuple('Navigation', [])):
    def __dafnystr__(self) -> str:
        return f'MotionSource.Navigation'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, MotionSource_Navigation)
    def __hash__(self) -> int:
        return super().__hash__()

class MotionSource_Nav2(MotionSource, NamedTuple('Nav2', [])):
    def __dafnystr__(self) -> str:
        return f'MotionSource.Nav2'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, MotionSource_Nav2)
    def __hash__(self) -> int:
        return super().__hash__()

