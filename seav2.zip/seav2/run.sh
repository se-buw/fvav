#!/bin/bash

# Formally Verified Autonomous Vehicles - SoSe 2026
# Start ROS2 mapping/navigation, RViz, YOLO, Dafny verification,
# and the runtime motion-safety verifier.

cd ~/seav2

# Build workspace first
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash

# 1. Start online async mapping
gnome-terminal --window -- bash -c "
cd ~/seav2
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch seav2 online_async_launch.py \
params_file:=./src/seav2/config/mapper_params_online_async.yaml \
use_sim_time:=false
exec bash
"

# 2. Start RViz
gnome-terminal --window -- bash -c "
cd ~/seav2
source /opt/ros/humble/setup.bash
source install/setup.bash
rviz2
exec bash
"

# 3. Start Nav2 navigation
gnome-terminal --window -- bash -c "
cd ~/seav2
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch seav2 navigation_launch.py \
use_sim_time:=false
exec bash
"

# 4. Start YOLO sign node
gnome-terminal --window -- bash -c "
cd ~/seav2
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run yolo_sign_node yolo_node --ros-args \
-p model_path:=/home/seav/seav2/src/yolo1/my_model/my_model.pt \
-p image_topic:=/image_raw/compressed \
-p conf_thres:=0.1 \
-p imgsz:=160 \
-p show:=false
exec bash
"

# 5. Verify all motion-safety Dafny models
gnome-terminal --window -- bash -c "
cd ~/seav2/src/motion_safety_verifier
./verify_all.sh
exec bash
"

# 6. Verify YOLO Dafny model
gnome-terminal --window -- bash -c "
cd ~/seav2/src/yolo_sign_node
dafny verify yolo_sign_node_verification.dfy
exec bash
"

# 7. Start runtime motion-safety verifier
gnome-terminal --window -- bash -c "
cd ~/seav2
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run motion_safety_verifier motion_safety_verifier
exec bash
"