import sys
import subprocess
import importlib.util
from pathlib import Path
PACKAGE_ROOT = Path(__file__).resolve().parent.parent

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan


# ---------------------------------------------------------
# Existing generated Dafny module
# ---------------------------------------------------------

DAFNY_PY_PATH = PACKAGE_ROOT / 'motion_safety_verifier_dafny-py'

sys.path.append(str(DAFNY_PY_PATH))

try:
    import module_ as dafny_module
    DAFNY_IMPORT_OK = True
except Exception as e:
    dafny_module = None
    DAFNY_IMPORT_OK = False
    DAFNY_IMPORT_ERROR = str(e)


# ---------------------------------------------------------
# Generated Obstacle Safety Dafny module
# ---------------------------------------------------------

OBSTACLE_MODULE_FILE = (
    PACKAGE_ROOT / 'obstacle_safety_dafny-py' / 'module_.py'
)

OBSTACLE_DAFNY_RUNTIME = (
    PACKAGE_ROOT / 'obstacle_safety_dafny-py'
)

sys.path.insert(0, str(OBSTACLE_DAFNY_RUNTIME))

try:
    obstacle_spec = importlib.util.spec_from_file_location(
        'obstacle_dafny_module',
        OBSTACLE_MODULE_FILE
    )

    obstacle_dafny_module = importlib.util.module_from_spec(
        obstacle_spec
    )

    obstacle_spec.loader.exec_module(
        obstacle_dafny_module
    )

    import _dafny

    OBSTACLE_DAFNY_IMPORT_OK = True

except Exception as e:
    obstacle_dafny_module = None
    OBSTACLE_DAFNY_IMPORT_OK = False
    OBSTACLE_DAFNY_IMPORT_ERROR = str(e)


# ---------------------------------------------------------
# ROS2 Motion Safety Verifier
# ---------------------------------------------------------

class MotionSafetyVerifier(Node):

    def __init__(self):
        super().__init__('motion_safety_verifier')

        self.latest_cmd = None
        self.latest_scan_min = None

        # Obstacle safety distance in metres
        self.obstacle_threshold = 1.00

        self.get_logger().info(
            'Dafny Motion Safety Verification started'
        )

        # Check original generated Dafny module
        if DAFNY_IMPORT_OK:
            self.get_logger().info(
                'Generated Dafny Python module imported successfully'
            )
        else:
            self.get_logger().error(
                'Failed to import generated Dafny Python module'
            )
            self.get_logger().error(
                DAFNY_IMPORT_ERROR
            )

        # Check obstacle safety generated Dafny module
        if OBSTACLE_DAFNY_IMPORT_OK:
            self.get_logger().info(
                'Generated Dafny obstacle safety module imported successfully'
            )
        else:
            self.get_logger().error(
                'Failed to import generated Dafny obstacle safety module'
            )
            self.get_logger().error(
                OBSTACLE_DAFNY_IMPORT_ERROR
            )

        # Run all Dafny verification files
        script_path = PACKAGE_ROOT / 'verify_all.sh'

        result = subprocess.run(
            ['bash', str(script_path)],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            self.get_logger().info(
                'Dafny verification successful'
            )

            self.get_logger().info(
                'Verified property 1: '
                'joystick has highest priority in twist_mux'
            )

            self.get_logger().info(
                'Verified property 2: '
                'Ackermann controller uses /cmd_vel_safe'
            )

            self.get_logger().info(
                'Verified property 3: '
                'complete motion safety pipeline is valid'
            )

            self.get_logger().info(
                'Verified property 4: '
                'obstacle safety requirement is valid'
            )

        else:
            self.get_logger().error(
                'Dafny verification failed'
            )
            self.get_logger().error(
                result.stderr
            )

        # Robot velocity command
        self.create_subscription(
            Twist,
            '/cmd_vel_unstamped',
            self.cmd_vel_safe_callback,
            10
        )

        # LiDAR
        self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        # Runtime safety check every 2 seconds
        self.create_timer(
            2.0,
            self.runtime_safety_check
        )

    def cmd_vel_safe_callback(self, msg):
        self.latest_cmd = msg

    def scan_callback(self, msg):

        valid_ranges = [
            r for r in msg.ranges
            if r > msg.range_min and r < msg.range_max
        ]

        if valid_ranges:
            self.latest_scan_min = min(valid_ranges)

    def runtime_safety_check(self):

        if self.latest_cmd is None:
            self.get_logger().warn(
                'Runtime check: '
                'no /cmd_vel_unstamped command received yet'
            )
            return

        if self.latest_scan_min is None:
            self.get_logger().warn(
                'Runtime check: '
                'no valid /scan data received yet'
            )
            return

        if not OBSTACLE_DAFNY_IMPORT_OK:
            self.get_logger().error(
                'Obstacle Dafny module is not available'
            )
            return

        # Convert ROS values to Dafny real values
        speed = _dafny.BigRational(
            str(self.latest_cmd.linear.x)
        )

        distance = _dafny.BigRational(
            str(self.latest_scan_min)
        )

        threshold = _dafny.BigRational(
            str(self.obstacle_threshold)
        )

        # Safety decision comes from generated Dafny code
        is_safe = (
            obstacle_dafny_module
            .default__
            .ObstacleSafety(
                speed,
                distance,
                threshold
            )
        )

        if not is_safe:

            self.get_logger().error(
                f'Dafny obstacle safety UNSAFE: '
                f'speed={self.latest_cmd.linear.x:.2f} m/s, '
                f'nearest obstacle='
                f'{self.latest_scan_min:.2f} m'
            )

        else:

            self.get_logger().info(
                f'Dafny obstacle safety SAFE: '
                f'speed={self.latest_cmd.linear.x:.2f} m/s, '
                f'nearest obstacle='
                f'{self.latest_scan_min:.2f} m'
            )


def main(args=None):

    rclpy.init(args=args)

    node = MotionSafetyVerifier()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()
