import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def ObstacleSafety(speed, distance, threshold):
        return not(((speed) > (_dafny.BigRational('5e-2'))) and ((distance) < (threshold)))

    @staticmethod
    def VerifyObstacleSafety(speed, distance, threshold):
        pass
        pass

