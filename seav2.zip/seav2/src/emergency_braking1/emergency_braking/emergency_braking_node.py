import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math


class EmergencyBrakingNode(Node):

    def __init__(self):
        super().__init__('emergency_braking_node')

        # LiDAR
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        # Nav2 command input
        self.cmd_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_callback,
            10
        )

        # Safe command output
        self.cmd_pub = self.create_publisher(
            Twist,
            '/cmd_vel_safe',
            10
        )

        self.last_cmd = Twist()
        self.min_front = float('inf')

        # --- SAFETY DISTANCES (tune later) ---
        self.SLOW_DIST = 1.5   # start slowing
        self.STOP_DIST = 0.7   # emergency stop

        # Speed scaling
        self.SLOW_FACTOR = 0.3  # 30% speed

        self.get_logger().info("Emergency braking SAFETY FILTER started")

    def cmd_callback(self, msg):
        self.last_cmd = msg

    def scan_callback(self, msg):
        ranges = [
            d for d in msg.ranges
            if not math.isinf(d) and not math.isnan(d) and d > 0.05
        ]

        if ranges:
            self.min_front = min(ranges)

        safe_cmd = Twist()
        safe_cmd.linear.x = self.last_cmd.linear.x
        safe_cmd.angular.z = self.last_cmd.angular.z

        # 🔴 EMERGENCY STOP
        if self.min_front < self.STOP_DIST and safe_cmd.linear.x > 0:
            safe_cmd.linear.x = 0.0
            self.get_logger().error("EMERGENCY STOP")

        # 🟡 SLOW DOWN
        elif self.min_front < self.SLOW_DIST and safe_cmd.linear.x > 0:
            safe_cmd.linear.x *= self.SLOW_FACTOR
            self.get_logger().warn("Obstacle close → slowing down")

        # 🟢 Otherwise pass command unchanged
        self.cmd_pub.publish(safe_cmd)


def main():
    rclpy.init()
    node = EmergencyBrakingNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

