import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math


class EmergencyBrake(Node):

    def __init__(self):
        super().__init__('emergency_brake')

        self.safe_dist = 0.6  # meters

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        self.get_logger().info("Emergency Braking Node Started")

    def scan_callback(self, msg):
        valid_ranges = [
            r for r in msg.ranges
            if not math.isinf(r) and not math.isnan(r)
        ]

        if len(valid_ranges) == 0:
            return

        min_scan_dist = min(valid_ranges)

        if min_scan_dist < self.safe_dist:
            stop_cmd = Twist()
            stop_cmd.linear.x = 0.0
            stop_cmd.angular.z = 0.0
            self.cmd_pub.publish(stop_cmd)

            self.get_logger().warn(
                f"EMERGENCY BRAKE! Obstacle at {min_scan_dist:.2f} m"
            )


def main(args=None):
    rclpy.init(args=args)
    node = EmergencyBrake()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

