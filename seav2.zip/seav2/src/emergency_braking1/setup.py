from setuptools import find_packages, setup

package_name = 'emergency_braking'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ragini',
    maintainer_email='ragini@todo.todo',
    description='Emergency braking node',
    license='TODO: License declaration',
    entry_points={
        'console_scripts': [
            'emergency_braking_node = emergency_braking.emergency_braking_node:main',
        ],
    },
)

