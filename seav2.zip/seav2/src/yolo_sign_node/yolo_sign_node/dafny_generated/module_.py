import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_


class Command:
    @_dafny.classproperty
    def AllSingletonConstructors(cls):
        return [Command_Left(), Command_Right(), Command_Stop(), Command_Straight(), Command_UTurn()]
    @classmethod
    def default(cls, ):
        return lambda: Command_Left()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_Left(self) -> bool:
        return isinstance(self, Command_Left)
    @property
    def is_Right(self) -> bool:
        return isinstance(self, Command_Right)
    @property
    def is_Stop(self) -> bool:
        return isinstance(self, Command_Stop)
    @property
    def is_Straight(self) -> bool:
        return isinstance(self, Command_Straight)
    @property
    def is_UTurn(self) -> bool:
        return isinstance(self, Command_UTurn)

class Command_Left(Command, NamedTuple('Left', [])):
    def __dafnystr__(self) -> str:
        return f'Command.Left'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Command_Left)
    def __hash__(self) -> int:
        return super().__hash__()

class Command_Right(Command, NamedTuple('Right', [])):
    def __dafnystr__(self) -> str:
        return f'Command.Right'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Command_Right)
    def __hash__(self) -> int:
        return super().__hash__()

class Command_Stop(Command, NamedTuple('Stop', [])):
    def __dafnystr__(self) -> str:
        return f'Command.Stop'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Command_Stop)
    def __hash__(self) -> int:
        return super().__hash__()

class Command_Straight(Command, NamedTuple('Straight', [])):
    def __dafnystr__(self) -> str:
        return f'Command.Straight'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Command_Straight)
    def __hash__(self) -> int:
        return super().__hash__()

class Command_UTurn(Command, NamedTuple('UTurn', [])):
    def __dafnystr__(self) -> str:
        return f'Command.UTurn'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Command_UTurn)
    def __hash__(self) -> int:
        return super().__hash__()


class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()


class Box:
    @classmethod
    def default(cls, ):
        return lambda: Box_Box(_dafny.BigRational(), _dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, "")))
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_Box(self) -> bool:
        return isinstance(self, Box_Box)

class Box_Box(Box, NamedTuple('Box', [('conf', Any), ('name', Any)])):
    def __dafnystr__(self) -> str:
        return f'Box.Box({_dafny.string_of(self.conf)}, {self.name.VerbatimString(True)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Box_Box) and self.conf == __o.conf and self.name == __o.name
    def __hash__(self) -> int:
        return super().__hash__()


class YoloNode:
    def  __init__(self):
        pass

    def __dafnystr__(self) -> str:
        return "_module.YoloNode"
    def GetBestDetection(self, boxes, conf__thres):
        found: bool = False
        best__conf: _dafny.BigRational = _dafny.BigRational()
        best__name: _dafny.Seq = _dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, ""))
        found = False
        best__conf = _dafny.BigRational('0e0')
        best__name = _dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, ""))
        d_0_i_: int
        d_0_i_ = 0
        while (d_0_i_) < (len(boxes)):
            d_1_b_: Box
            d_1_b_ = (boxes)[d_0_i_]
            if ((d_1_b_).conf) >= (conf__thres):
                if (not(found)) or (((d_1_b_).conf) > (best__conf)):
                    found = True
                    best__conf = (d_1_b_).conf
                    best__name = (d_1_b_).name
            d_0_i_ = (d_0_i_) + (1)
        return found, best__conf, best__name

    @staticmethod
    def ClassToCmd(c):
        if (c) == (_dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, "left"))):
            return Option_Some(Command_Left())
        elif (c) == (_dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, "right"))):
            return Option_Some(Command_Right())
        elif (c) == (_dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, "stop"))):
            return Option_Some(Command_Stop())
        elif (c) == (_dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, "straight"))):
            return Option_Some(Command_Straight())
        elif (c) == (_dafny.SeqWithoutIsStrInference(map(_dafny.CodePoint, "u_turn"))):
            return Option_Some(Command_UTurn())
        elif True:
            return Option_None()

