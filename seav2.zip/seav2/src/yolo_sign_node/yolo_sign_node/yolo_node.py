#!/usr/bin/env python3

import os
import sys
import time
import threading
from pathlib import Path

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String

from ultralytics import YOLO


# ==========================================================
# Load Dafny-generated Python implementation
# ==========================================================

DAFNY_DIR = (
    Path(__file__).resolve().parent
    / "dafny_generated"
)

if not DAFNY_DIR.exists():
    raise RuntimeError(
        f"Dafny generated folder not found: {DAFNY_DIR}"
    )


sys.path.insert(
    0,
    str(DAFNY_DIR)
)

import module_ as dafny_module
import _dafny


class YoloSignNode(Node):

    def __init__(self):

        super().__init__(
            "yolo_sign_node"
        )

        # ==================================================
        # Parameters
        # ==================================================

        self.declare_parameter(
            "model_path",
            ""
        )

        self.declare_parameter(
            "image_topic",
            "/image_raw/compressed"
        )

        self.declare_parameter(
            "conf_thres",
            0.15
        )

        self.declare_parameter(
            "imgsz",
            320
        )

        self.declare_parameter(
            "publish_topic",
            "/direction_cmd"
        )

        self.declare_parameter(
            "log_every_n",
            30
        )

        self.declare_parameter(
            "skip_frames",
            3
        )

        self.model_path = (
            self.get_parameter(
                "model_path"
            ).value
        )

        self.image_topic = (
            self.get_parameter(
                "image_topic"
            ).value
        )

        self.conf_thres = float(
            self.get_parameter(
                "conf_thres"
            ).value
        )

        self.imgsz = int(
            self.get_parameter(
                "imgsz"
            ).value
        )

        self.publish_topic = (
            self.get_parameter(
                "publish_topic"
            ).value
        )

        self.log_every_n = int(
            self.get_parameter(
                "log_every_n"
            ).value
        )

        self.skip_frames = int(
            self.get_parameter(
                "skip_frames"
            ).value
        )

        
        if self.conf_thres < 0.0:
            raise ValueError(
                "conf_thres must be >= 0.0"
            )

        if not self.model_path:
            self.get_logger().error(
                "model_path is empty."
            )
            raise RuntimeError(
                "model_path is empty"
            )

        if not os.path.exists(
            self.model_path
        ):
            self.get_logger().error(
                f"Model not found: {self.model_path}"
            )
            raise FileNotFoundError(
                self.model_path
            )

        # ==================================================
        # Load YOLO model
        # ==================================================

        self.get_logger().info(
            f"Loading YOLO model: {self.model_path}"
        )

        self.model = YOLO(
            self.model_path,
            task="detect"
        )

        self.get_logger().info(
            f"Model class names: {self.model.names}"
        )

        # ==================================================
        # Instantiate Dafny-generated verified component
        # ==================================================

        try:
            self.verifier = (
                dafny_module.YoloNode()
            )

        except Exception as exc:
            self.get_logger().error(
                "Failed to initialize "
                f"Dafny YoloNode: {exc}"
            )
            raise

        # ==================================================
        # ROS publisher / subscriber
        # ==================================================

        self.pub = self.create_publisher(
            String,
            self.publish_topic,
            10
        )

        self.sub = self.create_subscription(
            CompressedImage,
            self.image_topic,
            self.image_cb,
            qos_profile_sensor_data,
        )

        # ==================================================
        # Shared state
        # ==================================================

        self._lock = threading.Lock()

        self._latest_frame = None

        self._latest_stamp = (
            time.time()
        )

        self._frame_count = 0

        self._last_cmd = None

        self._last_cmd_time = 0.0

        # ==================================================
        # Worker thread
        # ==================================================

        self._running = True

        self._worker = threading.Thread(
            target=self.inference_loop,
            daemon=True,
        )

        self._worker.start()

        # Camera health timer
        self.create_timer(
            2.0,
            self.health_check
        )

        self.get_logger().info(
            f"✓ Subscribed to: "
            f"{self.image_topic}"
        )

        self.get_logger().info(
            f"✓ Publishing to: "
            f"{self.publish_topic}"
        )

        self.get_logger().info(
            f"✓ Confidence threshold: "
            f"{self.conf_thres}"
        )

        self.get_logger().info(
            f"✓ Image size: "
            f"{self.imgsz}"
        )

        self.get_logger().info(
            f"✓ Frame skip: "
            f"{self.skip_frames}"
        )

        self.get_logger().info(
            "✓ Dafny verified decision "
            "logic ACTIVE"
        )

    # ======================================================
    # Shutdown
    # ======================================================

    def destroy_node(self):

        self._running = False

        try:
            self._worker.join(
                timeout=1.0
            )
        except Exception:
            pass

        super().destroy_node()

    # ======================================================
    # Camera health check
    # ======================================================

    def health_check(self):

        dt = (
            time.time()
            - self._latest_stamp
        )

        if dt > 3.0:
            self.get_logger().warn(
                f"No images received for "
                f"{dt:.1f}s on "
                f"{self.image_topic}"
            )

    # ======================================================
    # Camera callback
    # ======================================================

    def image_cb(
        self,
        msg: CompressedImage
    ):

        self._frame_count += 1

        # Skip frames for CPU optimization
        if (
            self._frame_count
            % self.skip_frames
            != 0
        ):
            return

        np_arr = np.frombuffer(
            msg.data,
            dtype=np.uint8
        )

        frame = cv2.imdecode(
            np_arr,
            cv2.IMREAD_COLOR
        )

        if frame is None:
            self.get_logger().warn(
                "Failed to decode image"
            )
            return

        with self._lock:
            self._latest_frame = frame

            self._latest_stamp = (
                time.time()
            )

        if (
            self._frame_count
            % self.log_every_n
            == 0
        ):
            self.get_logger().info(
                f"Receiving images... "
                f"frame={self._frame_count}"
            )

    # ======================================================
    # YOLO + Dafny inference loop
    # ======================================================

    def inference_loop(self):

        while (
            self._running
            and rclpy.ok()
        ):

            frame = None

            with self._lock:
                if (
                    self._latest_frame
                    is not None
                ):
                    frame = (
                        self._latest_frame.copy()
                    )

            if frame is None:
                time.sleep(0.05)
                continue


            results = self.model(
                frame,
                imgsz=self.imgsz,
                conf=0.01,
                verbose=False,
            )

            if not results:
                time.sleep(0.05)
                continue

            boxes = results[0].boxes

            if (
                boxes is None
                or len(boxes) == 0
            ):
                time.sleep(0.05)
                continue

            # ==============================================
            # Convert YOLO detections to Dafny Box values
            # ==============================================

            dafny_boxes = []

            for b in boxes:

                conf = float(
                    b.conf.item()
                )

                cls_idx = int(
                    b.cls.item()
                )

                name = self.model.names.get(
                    cls_idx,
                    str(cls_idx)
                )

                normalized_name = (
                    name
                    .strip()
                    .lower()
                )

                self.get_logger().info(
                    f"YOLO RAW -> "
                    f"{name}: "
                    f"{conf:.2f}"
                )

                try:

                    dafny_name = (
                        self.to_dafny_string(
                            normalized_name
                        )
                    )

                    dafny_conf = (
                        self.to_dafny_real(
                            conf
                        )
                    )

                    dafny_box = (
                        dafny_module.Box_Box(
                            dafny_conf,
                            dafny_name,
                        )
                    )

                    dafny_boxes.append(
                        dafny_box
                    )

                except Exception as exc:

                    self.get_logger().error(
                        "Failed to construct "
                        f"Dafny Box: {exc}"
                    )

                    dafny_boxes = []
                    break

            if not dafny_boxes:
                time.sleep(0.05)
                continue

            # ==============================================
            # R1:
            # Dafny-verified best detection selection
            # ==============================================

            try:

                (
                    found,
                    best_conf,
                    best_name_dafny,
                ) = (
                    self.verifier
                    .GetBestDetection(
                        dafny_boxes,
                        self.to_dafny_real(
                            self.conf_thres
                        ),
                    )
                )

            except Exception as exc:

                self.get_logger().error(
                    "Dafny GetBestDetection "
                    f"failed: {exc}. "
                    "No command published."
                )

                time.sleep(0.05)
                continue

            if not found:
                time.sleep(0.05)
                continue

            best_name = (
                self.from_dafny_string(
                    best_name_dafny
                )
            )

            # ==============================================
            # R2:
            # Dafny-verified class -> command mapping
            # ==============================================

            try:

                dafny_option = (
                    dafny_module
                    .YoloNode
                    .ClassToCmd(
                        best_name_dafny
                    )
                )

                cmd = (
                    self.option_to_ros_command(
                        dafny_option
                    )
                )

            except Exception as exc:

                self.get_logger().error(
                    "Dafny ClassToCmd "
                    f"failed: {exc}. "
                    "No command published."
                )

                time.sleep(0.05)
                continue

            if cmd is None:

                self.get_logger().warn(
                    f"Dafny rejected "
                    f"class '{best_name}'"
                )

                time.sleep(0.05)
                continue

            # ==============================================
            # Publish only Dafny-approved command
            # ==============================================

            now = time.time()

            if (
                cmd != self._last_cmd
                or
                (
                    now
                    - self._last_cmd_time
                ) > 4.0
            ):

                out = String()

                out.data = cmd

                self.pub.publish(
                    out
                )

                self._last_cmd = cmd

                self._last_cmd_time = now

                self.get_logger().info(
                    "VERIFIED COMMAND -> "
                    f"{best_name} "
                    f"({float(best_conf):.2f}) "
                    f"-> {cmd}"
                )

            time.sleep(0.05)

    # ======================================================
    # Python string -> Dafny string
    # ======================================================

    def to_dafny_string(
        self,
        text: str
    ):

        return (
            _dafny.SeqWithoutIsStrInference(
                map(
                    _dafny.CodePoint,
                    text
                )
            )
        )

    # ======================================================
    # Dafny string -> Python string
    # ======================================================

    def from_dafny_string(
        self,
        value
    ):

        try:
            return "".join(
                str(c)
                for c in value
            )

        except Exception:
            return str(
                value
            )

    # ======================================================
    # Python float -> Dafny real
    # ======================================================

    def to_dafny_real(
        self,
        value: float
    ):

        return _dafny.BigRational(
            str(value)
        )

    # ======================================================
    # Dafny Option<Command> -> ROS command string
    # ======================================================

    def option_to_ros_command(
        self,
        option
    ):

        if option.is_None:
            return None

        if not option.is_Some:
            return None

        command = option.value

        if command.is_Left:
            return "LEFT"

        if command.is_Right:
            return "RIGHT"

        if command.is_Stop:
            return "STOP"

        if command.is_Straight:
            return "STRAIGHT"

        if command.is_UTurn:
            return "U_TURN"

        raise RuntimeError(
            f"Unknown Dafny command: "
            f"{command}"
        )


def main(args=None):

    rclpy.init(
        args=args
    )

    node = YoloSignNode()

    try:
        rclpy.spin(
            node
        )

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
