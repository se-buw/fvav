import shutil
import subprocess
from pathlib import Path

from setuptools import find_packages, setup


package_name = "yolo_sign_node"

# Uses the new Dafny 4.11 installation explicitly.
DAFNY = "dafny"

ROOT = Path(__file__).resolve().parent
PYTHON_PACKAGE = ROOT / package_name

DFY_FILE = ROOT / "yolo_sign_node_verification.dfy"


TEMP_BASE = PYTHON_PACKAGE / "_dafny_generated"
TEMP_OUTPUT = Path(str(TEMP_BASE) + "-py")


FINAL_OUTPUT = PYTHON_PACKAGE / "dafny_generated"



if TEMP_OUTPUT.exists():
    shutil.rmtree(TEMP_OUTPUT)

if FINAL_OUTPUT.exists():
    shutil.rmtree(FINAL_OUTPUT)



subprocess.check_call(
    [
        DAFNY,
        "verify",
        str(DFY_FILE),
    ],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)



subprocess.check_call(
    [
        DAFNY,
        "build",
        str(DFY_FILE),
        "-t:py",
        "-o",
        str(TEMP_BASE),
    ],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)



if not TEMP_OUTPUT.exists():
    raise RuntimeError(
        f"Dafny Python output was not generated: {TEMP_OUTPUT}"
    )




shutil.move(
    str(TEMP_OUTPUT),
    str(FINAL_OUTPUT),
)


(FINAL_OUTPUT / "__init__.py").touch(
    exist_ok=True
)



setup(
    name=package_name,

    version="0.0.0",

    packages=find_packages(
        exclude=["test"]
    ),

    data_files=[
        (
            "share/ament_index/resource_index/packages",
            [
                "resource/" + package_name
            ],
        ),

        (
            "share/" + package_name,
            [
                "package.xml"
            ],
        ),
    ],

    install_requires=[
        "setuptools",
    ],

    zip_safe=True,

    maintainer="seav",

    maintainer_email=(
        "swaraj.sudhakar.sonawane@uni-weimar.de"
    ),

    description=(
        "ROS2 YOLO traffic-sign recognition "
        "with Dafny-verified decision logic"
    ),

    license="TODO",

    extras_require={
        "test": [
            "pytest",
        ],
    },

    entry_points={
        "console_scripts": [
            "yolo_node = "
            "yolo_sign_node.yolo_node:main",
        ],
    },
)
