import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, RegisterEventHandler
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.event_handlers import OnProcessStart

from launch_ros.actions import Node


def generate_launch_description():

    package_name = 'seav2'  # <--- your package

    # Robot State Publisher (URDF + ros2_control)
    rsp = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory(package_name), 'launch', 'rsp.launch.py')
        ]),
        launch_arguments={
            'use_sim_time': 'false',
            'use_ros2_control': 'true'
        }.items()
    )

    # Twist mux + stamper -> acker_cont/reference
    twist_mux_params = os.path.join(get_package_share_directory(package_name), 'config', 'twist_mux.yaml')
    twist_mux = Node(
        package="twist_mux",
        executable="twist_mux",
        parameters=[twist_mux_params],
        remappings=[('/cmd_vel_out', '/cmd_vel_unstamped')]
    )

    twist_stamper = Node(
        package="twist_stamper",
        executable="twist_stamper",
        parameters=[{'use_sim_time': False}],
        remappings=[
            ('/cmd_vel_in', '/cmd_vel_unstamped'),
            ('/cmd_vel_out', '/acker_cont/reference')
        ]
    )

    # Controller manager (ros2_control)
    controller_params_file = os.path.join(get_package_share_directory(package_name), 'config', 'my_controllers.yaml')
    controller_manager = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[controller_params_file],
        remappings=[
            ("~/robot_description", "/robot_description"),
            # NOTE: set enable_odom_tf: false in my_controllers.yaml (EKF will publish odom->base_link)
            # ("/acker_cont/tf_odometry", "/tf"),
        ],
        output="both"
    )
    delayed_controller_manager = TimerAction(period=3.0, actions=[controller_manager])

    # Spawners
    ackermann_drive_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["acker_cont"],
    )
    delayed_ackermann_drive_spawner = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=controller_manager,
            on_start=[ackermann_drive_spawner],
        )
    )

    joint_broad_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_broad"],
    )
    delayed_joint_broad_spawner = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=controller_manager,
            on_start=[joint_broad_spawner],
        )
    )

    # -------------------------------
    # NEW: IMU filter (Madgwick) and EKF for odometry fusion + static TF
    # -------------------------------

    imu_filter_params = os.path.join(get_package_share_directory(package_name), 'config', 'imu_filter_madgwick.yaml')
    imu_filter = Node(
        package="imu_filter_madgwick",
        executable="imu_filter_madgwick_node",
        name="imu_filter_madgwick",
        output="screen",
        parameters=[imu_filter_params]
        # expects /imu/data_raw in frame imu_link, publishes /imu/data
    )

    ekf_params = os.path.join(get_package_share_directory(package_name), 'config', 'ekf_odom.yaml')
    ekf = Node(
        package="robot_localization",
        executable="ekf_node",
        name="ekf_odom",
        output="screen",
        parameters=[ekf_params]
        # publishes odom->base_link; slam_toolbox will publish map->odom
    )

    # Static TF: base_link -> imu_link (adjust xyz/rpy if needed)
    static_imu_tf = Node(
        package="tf2_ros",
        executable="static_transform_publisher",
        arguments=["0", "0", "0", "0", "0", "0", "base_link", "imu_link"],
        output="screen"
    )

    # Launch everything
    return LaunchDescription([
        rsp,
        twist_mux,
        twist_stamper,

        # IMU + EKF + static TF should be up early
        static_imu_tf,
        imu_filter,
        ekf,

        # controllers after a short delay
        delayed_controller_manager,
        delayed_ackermann_drive_spawner,
        delayed_joint_broad_spawner
    ])
