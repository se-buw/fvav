# Formally Verified Autonomous Vehicles – SoSe 2026

This project extends an existing ROS2-based autonomous vehicle platform with Dafny-based formal verification and runtime safety evaluation.

The system combines autonomous navigation, manual control, LiDAR sensing, camera-based traffic-sign recognition, Ackermann steering control, ROS2 command arbitration, and formally verified safety logic.

---

## Main Project Components

### 1. seav-ii

This folder contains the existing autonomous vehicle platform, including:

- ROS2 launch files
- Nav2 integration
- Ackermann steering control
- ROS2 control configuration
- hardware interface configuration
- robot description files
- simulation/world files
- Arduino bridge components

The current project extends this existing vehicle platform with formal verification and runtime safety evaluation.

### 2. motion_safety_verifier

This ROS2 package contains the Dafny models used to verify the motion-control and obstacle-safety properties.

The main Dafny files are:

- `motion_safety_verifier.dfy`
- `ControllerVerification.dfy`
- `RobotMotionSafetyVerification.dfy`
- `ObstacleSafetyVerification.dfy`

The verified properties include:

- manual joystick priority over autonomous Nav2 control
- intended controller-input safety
- combined motion-safety pipeline
- obstacle-safety logic based on vehicle speed and LiDAR distance

The package also contains:

- `verify_all.sh` for verifying all four Dafny models
- `wrapper.py` for ROS2 runtime integration
- Dafny-generated Python code used during runtime

The runtime motion-safety verifier uses:

- `/cmd_vel_unstamped` for the current forward velocity
- `/scan` for LiDAR obstacle-distance measurements

The configured obstacle-safety condition is:

```text
UNSAFE if:
speed > 0.05 m/s
AND
nearest obstacle distance < 1.00 m
```

Otherwise, the state is classified as SAFE according to the implemented predicate.

### 3. yolo_sign_node

This ROS2 package performs real-time traffic-sign recognition using YOLO.

The node:

- subscribes to `/image_raw/compressed`
- performs YOLO inference
- selects the best detection
- maps recognised classes to supported directional commands
- publishes the resulting command on `/direction_cmd`

The post-inference logic is formally specified in:

```text
yolo_sign_node_verification.dfy
```

Dafny verifies two main properties:

1. confidence-threshold and best-detection selection
2. restricted class-to-command mapping

The Dafny-generated Python implementation is directly imported by the runtime YOLO node.

The supported commands are:

- `LEFT`
- `RIGHT`
- `STOP`
- `STRAIGHT`
- `U_TURN`

The YOLO neural network itself is not formally verified. Formal verification is applied only to the post-inference decision logic.

### 4. emergency_braking1

This ROS2 Python package contains the emergency-braking implementation used by the vehicle platform.

### 5. serial

This folder contains the serial communication library used by the low-level vehicle communication components.

---

## Software Requirements

The project was developed using:

- Ubuntu
- ROS2 Humble
- Python 3
- Dafny 4.x
- Nav2
- ROS2 Control
- OpenCV
- Ultralytics YOLO
- NumPy

Dafny must be installed and available through the system PATH.

To check Dafny:

```bash
dafny --version
```

---

## Build Instructions

From the project root:

```bash
cd ~/seav2
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
```

---

## Formal Verification

### Motion-Safety Verification

Navigate to:

```bash
cd ~/seav2/src/motion_safety_verifier
```

Run:

```bash
./verify_all.sh
```

This verifies:

```text
motion_safety_verifier.dfy
ControllerVerification.dfy
RobotMotionSafetyVerification.dfy
ObstacleSafetyVerification.dfy
```

A successful run should complete all four Dafny verification steps without errors.

### YOLO Post-Inference Verification

Navigate to:

```bash
cd ~/seav2/src/yolo_sign_node
```

Run:

```bash
dafny verify yolo_sign_node_verification.dfy
```

Expected successful verification output:

```text
Dafny program verifier finished with 2 verified, 0 errors
```

---

## Runtime Motion-Safety Verifier

First source ROS2 and the built workspace:

```bash
source /opt/ros/humble/setup.bash
source ~/seav2/install/setup.bash
```

Run:

```bash
ros2 run motion_safety_verifier motion_safety_verifier
```

The runtime verifier receives:

- forward velocity from `/cmd_vel_unstamped`
- LiDAR measurements from `/scan`

It evaluates these values using the Dafny-generated obstacle-safety logic.

---

## Nav2 Command Check

To inspect the Nav2 motion-command output:

```bash
ros2 topic echo /cmd_vel_nav
```

After a navigation goal is provided, changing velocity values on this topic indicate that Nav2 is generating motion commands.

---

## YOLO Runtime Node

The YOLO node requires trained model weights supplied through the `model_path` parameter.

Example:

```bash
ros2 run yolo_sign_node yolo_node --ros-args \
  -p model_path:=/path/to/my_model.pt \
  -p image_topic:=/image_raw/compressed \
  -p conf_thres:=0.15 \
  -p imgsz:=320
```

Replace `/path/to/my_model.pt` with the actual location of the trained YOLO model.

The trained YOLO weight file is not included in this repository and must be provided separately.

---

## Important ROS2 Topics

| Topic | Purpose |
|---|---|
| `/cmd_vel_joy` | Manual joystick command |
| `/cmd_vel_tracker` | Tracking command |
| `/cmd_vel_direction` | Direction-related motion command |
| `/cmd_vel_safe` | Safety-related command path represented in the formal model |
| `/cmd_vel_nav` | Nav2 autonomous navigation command |
| `/cmd_vel_unstamped` | Selected runtime velocity command |
| `/acker_cont/reference` | Ackermann controller reference |
| `/scan` | LiDAR range measurements |
| `/image_raw/compressed` | Compressed camera stream |
| `/direction_cmd` | Directional command produced by the YOLO node |

---

## Motion Command Priorities

The configured motion-command priorities are:

| Command Source | Priority |
|---|---:|
| Joystick | 100 |
| Tracker | 20 |
| Direction | 15 |
| Navigation | 10 |
| Nav2 | 5 |

The Dafny verification checks that manual joystick control has a higher priority than autonomous Nav2 control.

---

## Project Structure

```text
seav2/
├── README.md
├── my_map_save.pgm
├── my_map_save.yaml
├── my_map_serial.data
├── my_map_serial.posegraph
├── run.sh
├── rviz2.rviz
└── src/
    ├── seav-ii/
    ├── serial/
    ├── emergency_braking1/
    ├── motion_safety_verifier/
    │   ├── ControllerVerification.dfy
    │   ├── motion_safety_verifier.dfy
    │   ├── ObstacleSafetyVerification.dfy
    │   ├── RobotMotionSafetyVerification.dfy
    │   ├── verify_all.sh
    │   ├── setup.py
    │   ├── setup.cfg
    │   ├── package.xml
    │   ├── resource/
    │   ├── test/
    │   ├── motion_safety_verifier/
    │   │   ├── __init__.py
    │   │   └── wrapper.py
    │   ├── motion_safety_verifier_dafny-py/
    │   └── obstacle_safety_dafny-py/
    └── yolo_sign_node/
        ├── yolo_sign_node_verification.dfy
        ├── setup.py
        ├── setup.cfg
        ├── package.xml
        ├── resource/
        ├── test/
        └── yolo_sign_node/
            ├── __init__.py
            ├── yolo_node.py
            └── dafny_generated/
```

---

## Verification and Runtime Workflow

The overall workflow is:

```text
Safety Requirement
        ↓
Dafny Specification
        ↓
Formal Verification
        ↓
Generated Python Logic
        ↓
ROS2 Runtime Integration
        ↓
Runtime Evaluation
```

Obstacle-safety runtime workflow:

```text
/cmd_vel_unstamped
        +
      /scan
        ↓
motion_safety_verifier
        ↓
Dafny-generated obstacle-safety logic
        ↓
SAFE / UNSAFE
```

YOLO post-inference workflow:

```text
/image_raw/compressed
        ↓
YOLO Neural-Network Inference
        ↓
Detected Boxes
        ↓
Dafny-generated GetBestDetection
        ↓
Dafny-generated ClassToCmd
        ↓
/direction_cmd
```

---

## Scope of Formal Verification

The formal verification in this project covers selected safety-related software properties.

The verified properties include:

- manual-override priority
- intended controller-input property
- combined motion-safety pipeline
- obstacle-safety logic
- YOLO confidence-selection logic
- YOLO restricted class-to-command mapping

The formal verification does not constitute verification of:

- the complete ROS2 framework
- the complete Nav2 stack
- the complete physical vehicle
- physical collision avoidance
- braking dynamics
- sensor uncertainty
- environmental conditions
- YOLO neural-network inference accuracy
- traffic-sign classification accuracy

The verification guarantees apply only to the properties and assumptions represented by the corresponding Dafny models.

---

## Runtime Safety Limitation

The current runtime motion-safety component performs safety monitoring.

It reports whether the measured state is SAFE or UNSAFE according to the implemented Dafny obstacle-safety predicate.

It does not automatically stop the vehicle when an UNSAFE state is detected.

---

## Course

**Formally Verified Autonomous Vehicles – SoSe 2026**

Bauhaus-Universität Weimar  
Faculty of Media  
Digital Engineering
